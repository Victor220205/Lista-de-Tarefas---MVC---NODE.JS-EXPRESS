import { store } from "../models/task.js";

export const getTasks = (_req, res) => {
  res.json(store.all());
};

export const addTask = (req, res) => {
  const { description } = req.body;
  if (!description || !description.trim()) {
    return res.status(400).json({ error: "description is required" });
  }
  const task = store.create(description.trim());
  res.status(201).json(task);
};

export const deleteTask = (req, res) => {
  const id = Number(req.params.id);
  const ok = store.remove(id);
  if (!ok) return res.status(404).json({ error: "task not found" });
  res.status(204).send();
};

export const toggleTask = (req, res) => {
  const id = Number(req.params.id);
  const task = store.toggle(id);
  if (!task) return res.status(404).json({ error: "task not found" });
  res.json(task);
};
