import { Router } from "express";
import { getTasks, addTask, deleteTask, toggleTask } from "../controllers/taskController.js";

const router = Router();

router.get("/", getTasks);
router.post("/", addTask);
router.delete("/:id", deleteTask);
router.patch("/:id/toggle", toggleTask);

export default router;
