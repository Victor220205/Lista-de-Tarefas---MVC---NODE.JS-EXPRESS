// Simple in-memory Task model
export class Task {
  constructor({ id, description, status = "pending" }) {
    this.id = id;
    this.description = description;
    this.status = status; // "pending" | "done"
  }
}

class TaskStore {
  constructor() {
    this.tasks = [];
    this.seq = 1;
  }
  all() { return this.tasks; }
  create(description) {
    const task = new Task({ id: this.seq++, description });
    this.tasks.push(task);
    return task;
  }
  remove(id) {
    const idx = this.tasks.findIndex(t => t.id === id);
    if (idx >= 0) this.tasks.splice(idx, 1);
    return idx >= 0;
  }
  toggle(id) {
    const task = this.tasks.find(t => t.id === id);
    if (task) {
      task.status = task.status === "done" ? "pending" : "done";
    }
    return task;
  }
}

export const store = new TaskStore();
