async function fetchTasks() {
  const res = await fetch("/api/tasks");
  const tasks = await res.json();
  render(tasks);
}

async function addTask(e) {
  e.preventDefault();
  const input = document.getElementById("taskInput");
  const description = input.value.trim();
  if (!description) return;
  await fetch("/api/tasks", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ description })
  });
  input.value = "";
  fetchTasks();
}

async function removeTask(id) {
  await fetch(`/api/tasks/${id}`, { method: "DELETE" });
  fetchTasks();
}

async function toggleTask(id) {
  await fetch(`/api/tasks/${id}/toggle`, { method: "PATCH" });
  fetchTasks();
}

function render(tasks) {
  const list = document.getElementById("taskList");
  list.innerHTML = "";
  if (tasks.length === 0) {
    list.innerHTML = "<li>Nenhuma tarefa ainda.</li>";
    return;
  }
  for (const t of tasks) {
    const li = document.createElement("li");
    li.className = "task";
    li.innerHTML = `
      <span class="desc ${t.status === "done" ? "done": ""}" onclick="toggleTask(${t.id})" title="Clique para marcar como concluída/pendente">${t.description}</span>
      <button class="remove" onclick="removeTask(${t.id})" aria-label="Remover">×</button>
    `;
    list.appendChild(li);
  }
}

document.getElementById("addForm").addEventListener("submit", addTask);
fetchTasks();
